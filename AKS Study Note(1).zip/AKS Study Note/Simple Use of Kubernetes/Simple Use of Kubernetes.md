# 1. 使用 Rancher Desktop 启动Kubernetes

下载安装 Rancher Desktop，下载网址为 [Rancher Desktop by SUSE](https://rancherdesktop.io/)，安装完成后选择 Kubernetes 版本并启动。

![[select Kubernetes.png]]

点击 OK 会自动下载并启动一个单节点的 k3s 集群。Rancher Desktop 会自动配置 `kubectl`，可以打开 PowerShell 或 cmd 执行 `kubectl get nodes` 可以看到一个 Ready 的节点。

![[access the cluster.png]]

# 2. 构建各种服务
## 2.1 Pod
### 2.1.1 使用 kubectl

使用 `kubectl` 命令构建 Pod，命令为 `kubectl run nginx --image=nginx --restart=Never`，使用命令 `kubectl get pods` 查看 Pod。

![[create pod with command.png]]

使用命令 `kubectl describe pod nginx` 查看 Pod 的详细信息。

![[pod details.png]]

### 2.1.2 使用 YAML 文件

使用 yaml 文件构建 Pod，文件内容如下：

```
apiVersion: v1
kind: Pod
metadata:
  name: nginx
  namespace: default
spec:
  containers:
  - name: nginx
    image: nginx:latest
    ports:
    - containerPort: 80
```

使用命令 `kubectl apply -f pod.yaml` 部署 Pod。

## 2.2 Deployment

使用 yaml 文件构建 Deployment，文件内容如下：

```
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-deploy
spec:
  replicas: 3
  selector:
    matchLabels:
      app: nginx
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:latest
        ports:
        - containerPort: 80
```

在文件中使用标签选择器将Pod与Deployment关联起来。使用 `kubectl apply -f deployment.yaml` 部署 Deployment。

![[create deployment with yaml.png]]

## 2.3 Namespace

使用 `kubectl` 命令构建 Namespace，命令为 `kubectl create namespace my-namespace`，使用命令 `kubectl get namespaces` 查看 Namespace。

![[create namespace with command.png]]

在创建 Namespaces 后，可以使用 `kubectl` 命令来在特定的 Namespaces 中操作资源。例如，要在特定的 Namespaces 中查看 Pod，可以使用命令 `kubectl get pod -n my-namespace`。 要访问不同 Namespaces 中的资源，可以在资源名称前加上 Namespaces 的前缀。例如，要访问名为 my-pod 的 Pod，它位于 my-namespace 中，可以使用命令`kubectl get pod my-pod -n my-namespace`。

## 2.4 Service
### 2.4.1 使用 kubectl

使用 `kubectl` 命令构建 Service，命令为 `kubectl expose pod nginx --port=80 --target-port=80 --type=ClusterIP`，使用命令 `kubectl get svc` 查看 Service。

![[create service with command.png]]

### 2.4.2 使用 YAML 文件

使用 yaml 文件构建 Service，文件内容如下：

```
apiVersion: v1
kind: Service
metadata:
  name: nginx-svc
spec:
  selector:
    app: nginx          # 匹配带有该 label 的 pod
  ports:
    - protocol: TCP
      port: 80
      targetPort: 80
  type: ClusterIP
```

使用 `kubectl apply -f service.yaml` 部署 Service。

![[create service with yaml.png]]

## 2.5 PVC

使用 yaml 文件构建 PVC，文件内容如下：

```
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: my-pvc
  namespace: default
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 1Gi
  storageClassName: local-path
```

使用 `kubectl apply -f pvc.yaml` 部署 PVC。

![[create pvc with yaml.png]]

## 2.6 Ingress

使用 yaml 文件构建 Ingress，文件内容如下：

```
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: my-ingress
spec:
  rules:
  - host: myapp.example.com
    http:
      paths:
      - pathType: Prefix
        path: "/"
        backend:
          service:
            name: nginx-svc
            port:
              number: 80
```

使用 `kubectl apply -f ingress.yaml` 部署 Ingress。

![[create ingress with yaml.png]]

## 2.7 ConfigMap

使用 yaml 文件构建 ConfigMap，文件内容如下：

```
apiVersion: v1
kind: ConfigMap
metadata:
  name: app-config
data:
  app.properties: |
    key1=value1
    key2=value2
```

## 2.8 Secret

使用 yaml 文件构建 Secret，文件内容如下：

```
apiVersion: v1
kind: Secret
metadata:
  name: db-secret
type: Opaque
data:
  username: cm9vdA==
  password: cGFzcw==
```

其中，定义了两个数据项 username 和 password，这些数据项的值被进行了 Base64 编码。

## 2.9 把 Secret 和 ConfigMap 挂载到 Deployment 中

当使用 Secret 和 ConfigMap 时，可以将它们的数据挂载到 Deployment 中的容器中，以便容器可以访问这些配置数据。这可以通过在 Deployment 的 yaml 文件中指定卷挂载和容器环境变量来实现，文件内容如下：

```
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-deploy
spec:
  replicas: 2
  selector:
    matchLabels:
      app: my-app
  template:
    metadata:
      labels:
        app: my-app
    spec:
      containers:
      - name: my-container
        image: nginx
        volumeMounts:
        - name: config-volume
	  mountPath: /etc/config 
        - name: secret-volume
          mountPath: /etc/secret
      volumes:
      - name: config-volume
        configMap:
          name: app-config
      - name: secret-volume
	secret: 
	  name: db-secret
```

# 3. 通过 Helm 部署服务

下载安装 Helm，下载网址为 [Releases · helm/helm](https://github.com/helm/helm/releases)。解压缩后在系统环境变量中添加 Helm 的路径。

![[helm version.png]]

添加一个 chart 仓库，查看已安装的 charts 列表。

![[chart.png]]

通过 helm install 命令安装 charts。

![[helm install.png]]

helm list 命令列出所有可被部署的版本。

![[helm list.png]]

helm uninstall 命令卸载你的版本。

![[helm uninstall.png]]

helm upgrade 一次升级操作会使用已有的 release 并根据你提供的信息对其进行升级。通过更改值文件和使用命令行选项，你可以修改 Helm Chart 的配置设置。例如，可以通过命令 `helm upgrade <release-name> <chart-name> -f values.yaml` 来更改 Helm Chart 部署的配置。其中 `<release-name>` 是已部署的 Helm Chart 的名称，`<chart-name>` 是 Helm Chart 的名称或路径，`-f values.yaml` 用于指定自定义的值文件。通过这种方式，你可以根据需要修改 Helm Chart 的配置设置，而无需修改原始的 Helm Chart 文件。

可以使用 helm get values 命令来看看配置值是否真的生效了。