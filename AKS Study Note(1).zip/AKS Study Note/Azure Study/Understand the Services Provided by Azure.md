# 1. Kubernetes Service

是 Azure 提供的托管 Kubernetes 服务。它简化了 Kubernetes 集群的创建、配置和管理，无需自己维护 Kubernetes 控制平面，即可轻松地在 Azure 上部署、管理和扩展容器化应用程序。

# 2. Container Registries

是一个托管的 Docker 容器注册表服务，用于存储和管理Docker镜像。它提供了可靠的、安全的方式来存储和分发容器镜像，供部署到 Azure 容器实例、AKS 等环境使用。

# 3. Function App

是一种无服务器计算服务，它使您能够以事件驱动的方式运行代码。通过 Azure Function App，您可以编写和部署小型独立的函数，而无需关心基础设施的管理，实现按需扩展和低成本运行。

特定的事件可以触发函数执行，事件可以是各种来源和类型，例如：
- HTTP 触发器：函数可以通过 HTTP 请求来触发执行，例如通过 HTTP POST 请求调用函数的 API 端点。
- 定时触发器：函数可以根据预定的时间表和计划来触发执行，例如每隔一段时间执行一次函数。
- 队列触发器：函数可以监听消息队列，当有新的消息到达队列时自动触发执行函数。
- Blob 触发器：函数可以监视 Azure Blob 存储中的文件，当有新的文件上传或更改时触发执行函数。
- Cosmos DB 触发器：函数可以监听 Azure Cosmos DB 数据库的更改，当有新的文档插入或更新时触发执行函数。
- Event Grid 触发器：函数可以订阅 Azure Event Grid 事件，当特定类型的事件发生时触发执行函数。

# 4. Virtual Machines

提供了在云中运行的可扩展计算资源。可以在 Azure 上创建和管理虚拟机，选择不同的操作系统和配置，以满足各种工作负载需求，如应用程序托管、开发测试、数据处理等。

# 5. Azure Database for MySQL/PostgreSQL/MariaDB

Azure 提供的托管的关系型数据库服务，支持 MySQL、PostgreSQL 和 MariaDB。这些服务提供高可用性、可伸缩性和自动化的数据库管理功能，可以轻松地部署和管理云中的关系型数据库。

# 6. Storage

是一种持久性云存储服务，可用于存储和访问各种类型的数据，如文件、Blob 对象（Binary Large Object，比如图像、音频、视频文件等）、表格数据和队列消息。它提供了高可用性、可伸缩性和安全性，适用于各种应用程序和场景。统一的数据持久化底座，支持大规模扩展和冗余。