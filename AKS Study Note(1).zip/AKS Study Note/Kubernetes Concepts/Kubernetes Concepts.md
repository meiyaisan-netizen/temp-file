# 1. 概要

Kubernetes 源于希腊语，意为“舵手”或“飞行员”。缩写为 K8s 是因为 K 和 s 之间有 8 个字符的关系。 Google 在 2014 年开源了 Kubernetes 项目。 Kubernetes 建立在 Google 大规模运行生产工作负载十几年经验的基础上，结合了社区中最优秀的想法和实践。

## 1.1 Kubernetes 的作用

容器是打包和运行应用程序的好方式。在生产环境中， 你需要管理运行着应用程序的容器，并确保服务不会下线。 例如，如果一个容器发生故障，则你需要启动另一个容器。 如果此行为交由给系统处理，会更容易一些。这就是 Kubernetes 要来做的事情。 Kubernetes 提供一个可弹性运行分布式系统的框架。 Kubernetes 会满足你的扩展要求、故障转移你的应用、提供部署模式等。Kubernetes 为你提供：
- 服务发现和负载均衡：Kubernetes 可以使用 DNS 名称或自己的 IP 地址来暴露容器。 如果进入容器的流量很大， Kubernetes 可以负载均衡并分配网络流量，从而使部署稳定。
- 存储编排：Kubernetes 允许你自动挂载你选择的存储系统，例如本地存储、公共云提供商等。
- 自动部署和回滚：你可以使用 Kubernetes 描述已部署容器的所需状态， 它可以以受控的速率将实际状态更改为期望状态。 例如，你可以自动化 Kubernetes 来为你的部署创建新容器， 删除现有容器并将它们的所有资源用于新容器。
- 自动完成装箱计算：你为 Kubernetes 提供许多节点组成的集群，在这个集群上运行容器化的任务。 你告诉 Kubernetes 每个容器需要多少 CPU 和内存 (RAM)。 Kubernetes 可以将这些容器按实际情况调度到你的节点上，以最佳方式利用你的资源。
- 自我修复：Kubernetes 将重新启动失败的容器、替换容器、杀死不响应用户定义的运行状况检查的容器， 并且在准备好服务之前不将其通告给客户端。
- 密钥与配置管理：Kubernetes 允许你存储和管理敏感信息，例如密码、OAuth 令牌和 SSH 密钥。 你可以在不重建容器镜像的情况下部署和更新密钥和应用程序配置，也无需在堆栈配置中暴露密钥。
- 批处理执行：除了服务外，Kubernetes 还可以管理你的批处理和 CI（持续集成）工作负载，如有需要，可以替换失败的容器。
- 水平扩缩：使用简单的命令、用户界面或根据 CPU 使用率自动对你的应用进行扩缩。
- IPv4/IPv6 双栈：为 Pod（容器组）和 Service（服务）分配 IPv4 和 IPv6 地址。
- 为可扩展性设计：在不改变上游源代码的情况下为你的 Kubernetes 集群添加功能。

## 1.2 Kubernetes 不是什么

Kubernetes 不是传统的、包罗万象的 PaaS（平台即服务）系统。由于 Kubernetes 是在容器级别运行，而非在硬件级别，它提供了 PaaS 产品共有的一些普遍适用的功能， 例如部署、扩展、负载均衡，允许用户集成他们的日志记录、监控和警报方案。 但是，Kubernetes 不是单体式（monolithic）系统，那些默认解决方案都是可选、可插拔的。 Kubernetes 为构建开发人员平台提供了基础，但是在重要的地方保留了用户选择权，能有更高的灵活性。

Kubernetes：
- 不限制支持的应用程序类型。 Kubernetes 旨在支持极其多种多样的工作负载，包括无状态、有状态和数据处理工作负载。 如果应用程序可以在容器中运行，那么它应该可以在 Kubernetes 上很好地运行。
- 不部署源代码，也不构建你的应用程序。 持续集成（CI）、交付和部署（CI/CD）工作流取决于组织的文化和偏好以及技术要求。
- 不提供应用程序级别的服务作为内置服务，例如中间件（例如消息中间件）、 数据处理框架（例如 Spark）、数据库（例如 MySQL）、缓存、集群存储系统 （例如 Ceph）。这样的组件可以在 Kubernetes 上运行，并且/或者可以由运行在 Kubernetes 上的应用程序通过可移植机制来访问。
- 不是日志记录、监视或警报的解决方案。 它集成了一些功能作为概念证明，并提供了收集和导出指标的机制。
- 不提供也不要求配置用的语言、系统（例如 jsonnet），它提供了声明性 API， 该声明性 API 可以由任意形式的声明性规范所构成。
- 不提供也不采用任何全面的机器配置、维护、管理或自我修复系统。
- 此外，Kubernetes 不仅仅是一个编排系统，实际上它消除了编排的需要。 编排的技术定义是执行已定义的工作流程：首先执行 A，然后执行 B，再执行 C。而 Kubernetes 包含了一组独立可组合的控制过程，可以持续地将当前状态驱动到所提供的预期状态。

# 2. Kubernetes 架构

![[Kubernetes cluster components.png]]

## 2.1 Control Plane

控制平面组件会为集群做出全局决策，比如资源的调度。 以及检测和响应集群事件，例如当不满足 Deployment 的 `replicas` 字段时，要启动新的 Pod。Control Plane 组件可以在集群中的任何节点上运行。 然而，为了简单起见，安装脚本通常会在同一个计算机上启动所有控制平面组件， 并且不会在此计算机上运行用户容器。

### 2.1.1 kube-apiserver

API 服务器是 Kubernetes Control Plane 的组件，该组件负责公开了 Kubernetes API，负责处理接受请求的工作。API 服务器是 Kubernetes 控制平面的前端。Kubernetes API 服务器的主要实现是 `kube-apiserver`。`kube-apiserver` 设计上考虑了水平扩缩，也就是说，它可通过部署多个实例来进行扩缩。 你可以运行 `kube-apiserver` 的多个实例，并在这些实例之间平衡流量。

### 2.1.2 etcd

一致且高可用的键值存储，用作 Kubernetes 所有集群数据的后台数据库。如果你的 Kubernetes 集群使用 etcd 作为其后台数据库，请确保你针对这些数据有一份备份计划。

### 2.1.3 kube-scheduler

`kube-scheduler` 是 Control Plane 的组件，负责监视新创建的、未指定运行 Node 的 Pod，并选择 Node 来让 Pod 在上面运行。调度决策考虑的因素包括单个 Pod 及多个 Pod 集合的资源需求、 软硬件及策略约束、亲和性及反亲和性规范、数据位置、工作负载间的干扰及最后时限。

### 2.1.4 kube-controller-manager

kube-controller-manager 是运行控制器进程的 Control Plane 组件。从逻辑上讲，每个控制器都是一个单独的进程， 但是为了降低复杂性，它们都被编译到同一个可执行文件，并在同一个进程中运行。控制器有许多不同类型，例如 Node 控制器，Job 控制器，EndpointSlice 控制器，ServiceAccount 控制器等。

### 2.1.5 cloud-controller-manager

一个 Kubernetes Control Plane 组件， 嵌入了特定于云平台的控制逻辑。 云控制器管理器（Cloud Controller Manager）允许将你的集群连接到云提供商的 API 之上， 并将与该云平台交互的组件同与你的集群交互的组件分离开来。`cloud-controller-manager` 仅运行特定于云平台的控制器。 因此如果你在自己的环境中运行 Kubernetes，或者在本地计算机中运行学习环境， 所部署的集群不包含云控制器管理器。与 `kube-controller-manager` 类似，`cloud-controller-manager` 将若干逻辑上独立的控制回路组合到同一个可执行文件中，以同一进程的方式供你运行。 你可以对其执行水平扩容（运行不止一个副本）以提升性能或者增强容错能力。

## 2.2 Node

Node 组件会在每个 Node 上运行，负责维护运行的 Pod 并提供 Kubernetes 运行时环境。

### 2.2.1 kubelet

`kubelet` 会在集群中每个节点（node）上运行。 它保证容器（containers）都运行在 Pod 中。kubelet 接收一组通过各类机制提供给它的 PodSpec，确保这些 PodSpec 中描述的容器处于运行状态且健康。kubelet 不会管理不是由 Kubernetes 创建的容器。

### 2.2.2 kube-proxy

kube-proxy 是集群中每个节点（node）上所运行的网络代理，实现 Kubernetes 服务（Service）概念的一部分。kube-proxy 维护节点上的一些网络规则， 这些网络规则会允许从集群内部或外部的网络会话与 Pod 进行网络通信。如果操作系统提供了可用的数据包过滤层，则 kube-proxy 会通过它来实现网络规则。否则，kube-proxy 仅做流量转发。如果你使用网络插件为 Service 实现本身的数据包转发， 并提供与 kube-proxy 等效的行为，那么你不需要在集群中的节点上运行 kube-proxy。

### 2.2.3 Container Runtime

这个基础组件使 Kubernetes 能够有效运行容器。 它负责管理 Kubernetes 环境中容器的执行和生命周期。Kubernetes 支持许多容器运行环境，例如 containerd 以及 Kubernetes CRI（容器运行环境接口）的其他任何实现。

# 3. 工作模型

Kubernetes 提供了几个内置的 API 来声明式管理工作负载及其组件。最终，你的应用以容器的形式在 Pods 中运行； 但是，直接管理单个 Pod 的工作量将会非常繁琐。例如，如果一个 Pod 失败了，你可能希望运行一个新的 Pod 来替换它。Kubernetes 可以为你完成这些操作。你可以使用 Kubernetes API 创建工作负载对象， 这些对象所表达的是比 Pod 更高级别的抽象概念，Kubernetes 控制平面根据你定义的工作负载对象规约自动管理 Pod 对象。

## 3.1 ReplicaSet

- 保证总有指定个数的 Pod 在运行
- 通过 pod selector 和 pod label 进行选择，将哪些 Pod 包含进来
- 适用于几乎无状态的服务
- 例子：静态 web 服务器

## 3.2 DaemonSet

- 保证每个宿主机上运行一个 Pod
- 通过 node selector 和 node label 进行选择，将哪些 Node 包含进来
- 适用于一些节点常驻服务
- 例子：各类 agent、log 收集、监控服务

## 3.3 Job

- 在 ReplicaSet 和 DaemonSet 中，如果 Pod 的进程退出了（即使正确退出），进程也会重启
- Job 则允许 Pod 中的进程正常退出，且不会再重启
- 适用于指定次数执行任务的场景
- 例子：数据备份操作

## 3.4 CronJob

- 基于时间来调度和创建 Job

## 3.5 StatefulSet

- 有稳定的网络标示和数据存储
- Pod 创建按顺序：索引从低到高
- Pod 销毁按顺序：索引从高到低
- 适用于有状态的服务
- 例子：数据库

# 4. 基本概念
## 4.1 Pod

Pod 是可以在 Kubernetes 中创建和管理的、最小的可部署的计算单元。Pod 是一组容器； 这些容器共享存储、网络、以及怎样运行这些容器的规约。Pod 中的内容总是并置（colocated）的并且一同调度，在共享的上下文中运行。Pod 所建模的是特定于应用的“逻辑主机”，其中包含一个或多个应用容器， 这些容器相对紧密地耦合在一起。 在非云环境中，在相同的物理机或虚拟机上运行的应用类似于在同一逻辑主机上运行的云应用。除了应用容器，Pod 还可以包含在 Pod 启动期间运行的 Init 容器。你也可以注入临时性容器来调试正在运行的 Pod。

Pod 的共享上下文包括一组 Linux 名字空间、控制组（CGroup）和可能一些其他的隔离方面， 即用来隔离容器的技术。 在 Pod 的上下文中，每个独立的应用可能会进一步实施隔离。Pod 类似于共享名字空间并共享文件系统卷的一组容器。Kubernetes 集群中的 Pod 主要有两种用法：
- 运行单个容器的 Pod。"每个 Pod 一个容器"模型是最常见的 Kubernetes 用例；在这种情况下，可以将 Pod 看作单个容器的包装器，并且 Kubernetes 直接管理 Pod，而不是容器。
- 运行多个协同工作的容器的 Pod。Pod 可以封装由紧密耦合且需要共享资源的多个并置容器组成的应用。这些位于同一位置的容器构成一个内聚单元。

## 4.2 Deployment

Deployment 用于管理运行一个应用负载的一组 Pod，通常适用于不保持状态的负载。一个 Deployment 为 Pod 提供声明式的更新能力。你负责描述 Deployment 中的目标状态，而 Deployment 控制器（Controller）以受控速率更改实际状态， 使其变为期望状态。你可以定义 Deployment 以创建新的 ReplicaSet，或删除现有 Deployment， 并通过新的 Deployment 收养其资源。

## 4.3 更新部署

当需要更新应用的时候，一版希望做到如下两点：
- 不停服务，不影响正在使用的用户
- 支持灰度发布，可以在全量更新前验证新版本时候工作正常

对此，k8s 中抽象出了 Deployment 的概念，对 ReplicaSet 模型中 Pod 的更新进行支持。目前支持两种更新策略：
- Recreate：销毁所有在运行的 Pod 后进行重建，这种策略的问题是会带来 downtime
- RollingUpdate：滚动升级，符合期望的两点目标

k8s 中的更新策略为 RollingUpdate，通过两个参数来配置具体的更新方法：
- max unavailable：指定能够同时进行更新的 Pod 的个数
- max surge：在更新过程中能够使用的额外的 Pod 的个数

## 4.4 Node

Kubernetes 通过将容器放入在节点（Node）上运行的 Pod 中来执行你的工作负载。节点可以是一个虚拟机或者物理机器，取决于所在的集群配置。每个节点包含运行 Pod 所需的服务；这些节点由控制面负责管理。通常集群中会有若干个节点；而在一个学习所用或者资源受限的环境中，你的集群中也可能只有一个节点。

## 4.5 ReplicaSet

ReplicaSet 的作用是维持在任何给定时间运行的一组稳定的副本 Pod。 通常，你会定义一个 Deployment，并用这个 Deployment 自动管理 ReplicaSet。ReplicaSet 的目的是维护一组在任何时候都处于运行状态的 Pod 副本的稳定集合。因此，它通常用来保证给定数量的、完全相同的 Pod 的可用性。

## 4.6 Service

将在集群中运行的应用通过同一个面向外界的端点公开出去，即使工作负载分散于多个后端也完全可行。Kubernetes 中 Service 是将运行在一个或一组 Pod 上的网络应用程序公开为网络服务的方法。Kubernetes 中 Service 的一个关键目标是让你无需修改现有应用以使用某种不熟悉的服务发现机制。你可以在 Pod 集合中运行代码，无论该代码是为云原生环境设计的，还是被容器化的老应用。你可以使用 Service 让一组 Pod 可在网络上访问，这样客户端就能与之交互。

对一些应用的某些部分，你可能希望将其公开于某外部 IP 地址， 也就是可以从集群外部访问的某个地址。Kubernetes Service 类型允许指定你所需要的 Service 类型。可用的 `type` 值及其行为有：
- ClusterIP：通过集群的内部 IP 公开 Service，选择该值时 Service 只能够在集群内部访问。 这也是你没有为 Service 显式指定 `type` 时使用的默认值。你可以使用 Ingress 或者 Gateway API 向公共互联网公开服务。
- NodePort：通过每个节点上的 IP 和静态端口（`NodePort`）公开 Service。为了让 Service 可通过节点端口访问，Kubernetes 会为 Service 配置集群 IP 地址，相当于你请求了 `type: ClusterIP` 的 Service。
- LoadBalancer：使用云平台的负载均衡器向外部公开 Service。Kubernetes 不直接提供负载均衡组件；你必须提供一个，或者将你的 Kubernetes 集群与某个云平台集成。
- ExternalName：将服务映射到 `externalName` 字段的内容（例如，映射到主机名 `api.foo.bar.example`）。该映射将集群的 DNS 服务器配置为返回具有该外部主机名值的 `CNAME` 记录。集群不会为之创建任何类型代理。

Service API 中的 `type` 字段被设计为层层递进的形式，每层都建立在前一层的基础上。但是，这种层层递进的形式有一个例外。你可以在定义 `LoadBalancer` Service 时禁止负载均衡器分配 NodePort。

## 4.7 Namespace

Namespace是一种逻辑隔离机制，用于将Kubernetes集群划分为多个虚拟集群。它允许在同一个集群中运行多个独立的应用程序或环境，每个命名空间拥有自己的资源配额、访问控制和其他配置。Namespace可以帮助组织和管理集群中的资源。

## 4.8 ConfigMap

ConfigMap 是一种 API 对象，用来将非机密性的数据保存到键值对中。使用时，Pod 可以将其用作环境变量、命令行参数或者存储卷中的配置文件。ConfigMap 将你的环境配置信息和容器镜像解耦，便于应用配置的修改。

## 4.9 Secret

Secret 是一种包含少量敏感信息例如密码、令牌或密钥的对象。这样的信息可能会被放在 Pod 规约中或者镜像中。使用 Secret 意味着你不需要在应用程序代码中包含机密数据。由于创建 Secret 可以独立于使用它们的 Pod，因此在创建、查看和编辑 Pod 的工作流程中暴露 Secret（及其数据）的风险较小。Kubernetes 和在集群中运行的应用程序也可以对 Secret 采取额外的预防措施， 例如避免将敏感数据写入非易失性存储。Secret 类似于 ConfigMap 但专门用于保存机密数据。

## 4.10 PersistentVolume

是集群中的一块存储，可以由管理员事先制备，或者使用存储类（Storage Class）来动态制备。 PersistentVolume 是集群资源，就像节点也是集群资源一样。PersistentVolume 和普通的 Volume 一样，也是使用 Volume 插件来实现的，只是它们拥有独立于任何使用 PersistentVolume 的 Pod 的生命周期。此 API 对象中记述了存储的实现细节，无论其背后是 NFS、iSCSI 还是特定于云平台的存储系统。

## 4.11 PersistentVolumeClaim

表达的是用户对存储的请求，概念上与 Pod 类似。Pod 会耗用节点资源，而 PersistentVolumeClaim 会耗用 PersistentVolume 资源。Pod 可以请求特定数量的资源（CPU 和内存）。同样 PersistentVolumeClaim 也可以请求特定的大小和访问模式（例如，可以挂载为 ReadWriteOnce、ReadOnlyMany、ReadWriteMany 或 ReadWriteOncePod）。

## 4.12 总结

- 最小计算单元 = Pod
- 最小通信单元 = Service
- 分组 = Labels
- 配置 = ConfigMap 和 Secret
- 无状态 Pod 调度 = ReplicaSet、DaemonSet、Job
- 更新部署 = Deployment
- 有状态 Pod 调度 = StatefulSet
- 存储 = PersistentVolume 以及之上的 PersistentVolumeClaim

