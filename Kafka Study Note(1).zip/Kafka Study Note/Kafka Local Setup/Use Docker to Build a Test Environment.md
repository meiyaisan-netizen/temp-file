# 1. 拉取 kafka 镜像

使用命令 `docker pull apache/kafka:4.2.0` 拉取镜像。

![[pull kafka image.png]]

# 2. 启动 kafka 容器

使用命令 `docker run -d --name kafka -p 9092:9092 apache/kafka:4.2.0` 启动容器。

![[run kafka container.png]]

# 3. 验证容器启动状态

使用命令 `docker ps` 查看容器启动状态。

![[verify container status.png]]

# 4. 进入 kafka 容器

使用命令 `docker exec -it kafka /bin/bash` 进入容器。

![[enter kafka container.png]]

# 5. 创建主题

使用命令 `/opt/kafka/bin/kafka-topics.sh --create --topic test --bootstrap-server localhost:9092` 创建一个名为 test 的主题。

![[create topic.png]]

# 6. 写入事件

使用命令 `/opt/kafka/bin/kafka-console-producer.sh --bootstrap-server localhost:9092 --topic test` 在主题 test 中写入事件。

![[write some events into the topic.png]]

用 Ctrl + C 可退出命令行。

# 7. 读事件

打开另一个终端会话，使用命令 `/opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic test --from-beginning` 读事件。

![[read the events.png]]

用 Ctrl + C 可退出命令行。

# 8. 通过 Kafka Connect 导入/导出数据

在 `D:\docker-kafka` 目录下创建文件 `docker-compose.yml`，文件内容如下：

```
services:
  kafka:
    image: apache/kafka:4.2.0
    container_name: kafka
    user: root
    ports:
      - "9092:9092"
      - "9093:9093" 
    environment:
      KAFKA_NODE_ID: 1
      KAFKA_PROCESS_ROLES: broker,controller
      KAFKA_CONTROLLER_QUORUM_VOTERS: 1@kafka:9093
      KAFKA_LISTENERS: PLAINTEXT://0.0.0.0:9092,CONTROLLER://0.0.0.0:9093
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:9092
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
      KAFKA_CONTROLLER_LISTENER_NAMES: CONTROLLER
      KAFKA_LOG_DIRS: /tmp/kraft-combined-logs
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
      KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR: 1
      KAFKA_TRANSACTION_STATE_LOG_MIN_ISR: 1
    volumes:
      - kafka_data:/tmp/kraft-combined-logs

  connect:
    image: apache/kafka:4.2.0
    container_name: kafka-connect
    ports:
      - "8083:8083"
    volumes:
      - ./connect-config:/config
      - ./data:/data
    command: /opt/kafka/bin/connect-standalone.sh /config/connect-standalone.properties /config/connect-file-source.properties /config/connect-file-sink.properties
    depends_on:
      - kafka
    environment:
      KAFKA_BOOTSTRAP_SERVERS: kafka:9092

volumes:
  kafka_data:
```

创建文件 `connect-config\connect-standalone.properties`，文件内容如下：

```
bootstrap.servers=kafka:9092
key.converter=org.apache.kafka.connect.json.JsonConverter
value.converter=org.apache.kafka.connect.json.JsonConverter
key.converter.schemas.enable=true
value.converter.schemas.enable=true
offset.storage.file.filename=/tmp/connect.offsets
offset.flush.interval.ms=10000
plugin.path=/opt/kafka/libs
```

创建文件 `connect-config\connect-file-source.properties`，文件内容如下：

```
name=local-file-source
connector.class=org.apache.kafka.connect.file.FileStreamSourceConnector
tasks.max=1
file=/data/test.txt
topic=connect-test
```

创建文件 `connect-config\connect-file-sink.properties`，文件内容如下：

```
name=local-file-sink
connector.class=org.apache.kafka.connect.file.FileStreamSinkConnector
tasks.max=1
file=/data/test.sink.txt
topics=connect-test
```

创建文件 `data\test.txt`，使用命令 `docker compose up -d` 启动所有服务。

![[start services.png]]

创建数据，并读取数据。

![[create and read data.png]]