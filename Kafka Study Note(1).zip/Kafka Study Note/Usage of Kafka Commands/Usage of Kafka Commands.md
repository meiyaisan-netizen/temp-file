# 1. 进入 Kafka 容器

使用命令 `docker exec -it kafka bash` 进入 Kafka 容器。

# 2. 创建 Topic

使用命令 `/opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --create --topic demo --partitions 3 --replication-factor 1` 创建 Topic。

![[create a topic.png]]

其中，`--partitions 3` 代表设定分区数为 3，`--replication-factor 1` 代表副本数量为 1。

# 3. 查看 Topic 详情

使用命令 /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --describe --topic demo 查看 Topic 详情，可以看到 3 个分区。

![[topic details.png]]

# 4. 启动生产者

使用命令 `/opt/kafka/bin/kafka-console-producer.sh --bootstrap-server localhost:9092 --topic demo` 启动生产者。

![[start producer.png]]

输入消息，

![[input messages.png]]

# 5. 启动消费者

另起一个终端，使用命令 `/opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic demo --group my-group --property print.offset=true` 启动消费者并指定消费者组。

![[start consumer.png]]

使用命令 `/opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --group my-group --describe` 查看特定消费者组的偏移量详情。

![[consumer group details.png]]

其中，CURRENT-OFFSET 表示该消费者组已消费到的偏移量；LOG-END-OFFSET 表示分区最新消息的偏移量；LAG 表示落后条数，即LOG-END-OFFSET - CURRENT-OFFSET。

启动两个消费者，并全部指定为 my group 消费者组，再次查看消费者组的详情。

![[two consumers group details.png]]

可以看到有一个消费者消费两个分区的消息。

启动三个消费者，并全部指定为 my group 消费者组，再次查看消费者组的详情。

![[group details.png]]

可以看到每个分区各被一个消费者消费。

启动四个消费者，并全部指定为 my group 消费者组，再次查看消费者组的详情。

![[four consumers group details.png]]

可以看到每个分区依然各被一个消费者消费，还有一个消费者只能处于空闲状态。

不停的启动生产者输入消息发现，在不指定分区的情况下，输入的消息是在三个分区之间随机分配的。但是一次性发送 15 条消息，不指定分区，会逐渐分布到不同分区。

# 6. 搭建集群

创建文件 `docker-compose.yml` 搭建集群，文件内容为，

```
services:
  kafka1:
    image: apache/kafka:4.2.0
    container_name: kafka1
    user: root
    ports:
      - "9092:9092"
    environment:
      KAFKA_NODE_ID: 1
      KAFKA_PROCESS_ROLES: broker,controller
      KAFKA_CONTROLLER_QUORUM_VOTERS: 1@kafka1:9093,2@kafka2:9093,3@kafka3:9093
      KAFKA_LISTENERS: PLAINTEXT://0.0.0.0:9092,CONTROLLER://0.0.0.0:9093
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka1:9092
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
      KAFKA_CONTROLLER_LISTENER_NAMES: CONTROLLER
      KAFKA_LOG_DIRS: /tmp/kraft-combined-logs
    volumes:
      - kafka1_data:/tmp/kraft-combined-logs

  kafka2:
    image: apache/kafka:4.2.0
    container_name: kafka2
    user: root
    ports:
      - "9093:9092"
    environment:
      KAFKA_NODE_ID: 2
      KAFKA_PROCESS_ROLES: broker,controller
      KAFKA_CONTROLLER_QUORUM_VOTERS: 1@kafka1:9093,2@kafka2:9093,3@kafka3:9093
      KAFKA_LISTENERS: PLAINTEXT://0.0.0.0:9092,CONTROLLER://0.0.0.0:9093
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka2:9092
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
      KAFKA_CONTROLLER_LISTENER_NAMES: CONTROLLER
      KAFKA_LOG_DIRS: /tmp/kraft-combined-logs
    volumes:
      - kafka2_data:/tmp/kraft-combined-logs

  kafka3:
    image: apache/kafka:4.2.0
    container_name: kafka3
    user: root
    ports:
      - "9094:9092"
    environment:
      KAFKA_NODE_ID: 3
      KAFKA_PROCESS_ROLES: broker,controller
      KAFKA_CONTROLLER_QUORUM_VOTERS: 1@kafka1:9093,2@kafka2:9093,3@kafka3:9093
      KAFKA_LISTENERS: PLAINTEXT://0.0.0.0:9092,CONTROLLER://0.0.0.0:9093
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka3:9092
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
      KAFKA_CONTROLLER_LISTENER_NAMES: CONTROLLER
      KAFKA_LOG_DIRS: /tmp/kraft-combined-logs
    volumes:
      - kafka3_data:/tmp/kraft-combined-logs

volumes:
  kafka1_data:
  kafka2_data:
  kafka3_data:
```

保存后在终端使用命令 `docker compose up -d` 启动集群，

![[start cluster.png]]

使用命令 `docker exec -it kafka1 bash` 进入任意容器，例如 kafka1。创建副本数量为 2，分区数量为 3 的 Topic。查看 Topic 详情，

![[topic details 1.png]]

可以看到 Leader 表示当前负责处理该分区所有读写请求的 Broker 节点 ID；Replicas 表示该分区所有副本所在的 Broker ID 列表，包括 Leader 和 Follower；Isr 表示当前与 Leader 保持同步的副本 Broker ID 集合，如果一个 Follower 副本数据落后太多或宕机，它会从 Isr 中被移除，直到追上进度，只有 Isr 中的副本才有资格被选举为新的 Leader。

使用命令 `docker stop kafka1` 模拟故障，例如 kafka1，它是分区 0 的 Leader，连接到仍在运行的 broker，例如 kafka2，再次查看主题详情。

![[topic details 2.png]]

会发现原本分区 0 的 Leader=1 变成了 Leader=2。生产者和消费者仍可正常工作。

重启 kafka1，等待几秒，再次 `--describe`，kafka1 会重新加入 Isr。

![[topic details 3.png]]
