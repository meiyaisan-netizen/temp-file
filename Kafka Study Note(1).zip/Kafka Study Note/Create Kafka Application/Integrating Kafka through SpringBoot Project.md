# 1. 生成 SpringBoot 项目

访问网址 [Spring Initializr](https://start.spring.io/) 选择项目为 Maven 项目，在 Dependencies 中添加 Spring Web 和 Kafka 依赖，生成 SpringBoot 项目。

![[springboot project.png]]

# 2. 配置 Kafka 相关参数

在 application.properties 中配置 Kafka 相关参数，例如：

```
###########【Kafka集群】###########  
spring.kafka.bootstrap-servers=worker1:9092,worker2:9093,worker3:9093  
###########【初始化生产者配置】###########  
# 重试次数  
spring.kafka.producer.retries=0  
# 应答级别:多少个分区副本备份完成时向生产者发送ack确认(可选0、1、all/-1)  
spring.kafka.producer.acks=1  
# 批量大小  
spring.kafka.producer.batch-size=16384  
# 提交延时  
spring.kafka.producer.properties.linger.ms=0  
# 生产端缓冲区大小  
spring.kafka.producer.buffer-memory = 33554432  
# Kafka提供的序列化和反序列化类  
spring.kafka.producer.key-serializer=org.apache.kafka.common.serialization.StringSerializer  
spring.kafka.producer.value-serializer=org.apache.kafka.common.serialization.StringSerializer  
###########【初始化消费者配置】###########  
# 默认的消费组ID  
spring.kafka.consumer.properties.group.id=defaultConsumerGroup  
# 是否自动提交offset  
spring.kafka.consumer.enable-auto-commit=true  
# 提交offset延时(接收到消息后多久提交offset)  
spring.kafka.consumer.auto-commit-interval=1000  
# 当kafka中没有初始offset或offset超出范围时将自动重置offset  
# earliest:重置为分区中最小的offset;  
# latest:重置为分区中最新的offset(消费分区中新产生的数据);  
# none:只要有一个分区不存在已提交的offset,就抛出异常;  
spring.kafka.consumer.auto-offset-reset=latest  
# 消费会话超时时间(超过这个时间consumer没有发送心跳,就会触发rebalance操作)  
spring.kafka.consumer.properties.session.timeout.ms=120000  
# 消费请求超时时间  
spring.kafka.consumer.properties.request.timeout.ms=180000  
# Kafka提供的序列化和反序列化类  
spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer  
spring.kafka.consumer.value-deserializer=org.apache.kafka.common.serialization.StringDeserializer
```

# 3. 实现消息生产者

创建 KafkaProducer 类实现消息生产者，内容如下，

```
package com.example.KafkaDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class KafkaProducer {

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    // 发送消息
    @GetMapping("/kafka/normal/{message}")
    public void sendMessage1(@PathVariable("message") String normalMessage) {
        kafkaTemplate.send("topic1", normalMessage);
    }

}
```

# 4. 实现消息消费者

创建 KafkaConsumer 类实现消息消费者，内容如下，

```
package com.example.KafkaDemo;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class KafkaConsumer {

    @KafkaListener(topics = { "topic1" })
    public void onMessage1(ConsumerRecord<?, ?> record) {
        
        // 消费的哪个topic、partition的消息,打印出消息内容
        System.out.println("简单消费：" + record.topic() + "-" + record.partition() + "-" + record.value());
    }

}
```

# 5. 运行测试

启动 Docker 中的 Kafka 容器，然后运行 SpringBoot 项目，项目启动成功后从浏览器访问 http://localhost:8080/kafka/normal/{message} 将 {message} 替换为要发送的消息。

![[localhost.png]]

在终端即可看到消费者打印的消息内容。