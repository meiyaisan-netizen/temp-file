# 1. Template API
## 1.1 template 更新

template 更新 API，使用 PUT 方法，路径变量为 templateId，请求的 body 内容包含持续标志 persistanceFlag 和频道消息列表 channelMessageList。channelMessageList中包含频道类型 channelType 和 消息信息列表 messageInfoList。messageInfoList中包含件名 subject、消息内容 message 和语言类型 language。将 RequestBody 中的数据更新到TemplateRegistrationGatewayRequestDto 中。


## 1.2 template 检索

template 检索 API，使用 GET 方法，请求参数包含检索对象频道 targetChannel 和检索对象语言 targetLanguage。API 响应为列表，包含多个有 templateId 和 template 检索结果 URL 属性的对象。

## 1.3 template 获取

template 获取 API，使用 GET 方法，路径变量为 templateId。API 响应为包含 templateId、频道消息列表 channelMessageList 和持续标志 persistanceFlag 的具体的 template 属性的对象。

## 1.4 template 删除

template 删除 API，使用 DELETE 方法，路径变量为 templateId。

## 1.5 template 批量注册

template 批量注册 API，使用 POST 方法，RequestBody 包含 template 列表 templateList。template 列表包含 templateId、频道消息列表 channelMessageList 和持续标志 persistanceFlag。

# 2. 通用变换参数 API
## 2.1 通用变换参数更新

通用变换参数更新 API，使用 PUT 方法，路径变量为通用变换参数 ID commonConversionParameterId，RequestBody 为更新请求（包含变换参数 conversionParameter）。将 RequestBody 的数据更新到 CommonConversionParameterRegistrationGatewayRequestDto 中。

## 2.2 通用变换参数获取

通用变换参数获取 API，使用 GET 方法，路径变量为通用变换参数 ID commonConversionParameterId。API 响应为包含变换参数 ID conversionParameterId 和变换参数 conversionParameter 属性的对象。

## 2.3 通用变换参数删除

通用变换参数删除 API，使用 DELETE 方法，路径变量为通用变换参数 ID commonConversionParameterId。

## 2.4 通用变换参数批量注册

通用变换参数批量注册 API，使用 POST 方法，RequestBody 包含变换参数对象列表 conversionParameterList。变换参数对象包含变换参数 ID conversionParameterId 和变换参数 conversionParameter。

# 3. 分发请求 API
## 3.1 接受分发 API
### 3.1.1 分发请求

分发请求 API，使用 POST 方法，RequestBody 为包含分发 ID deliveryId 和分发对象列表 deliveryTargetList 属性的对象。分发对象为包含分发对象 ID、对象频道、对象语言、分发信息、对象 template ID、变换参数、通用变换参数 ID、优先级和分发有效期时间。响应内容为包含分发请求 ID deliveryRequestId 和分发信息结果 URL deliveryInformationResultURL 属性的对象。

### 3.1.2 分发信息检索

分发信息检索 API，使用 GET 方法，请求参数为分发 ID 的列表。API 响应内容为包含分发请求 ID deliveryRequestId、分发 ID deliveryId 和分发信息结果 URL deliveryInformationResultURL 属性的对象列表。

### 3.1.3 分发信息获取

分发信息获取 API，使用 GET 方法，路径变量为分发请求 ID deliveryRequestId。API 响应内容为分发详细信息列表。

## 3.2 分发预约 API

分发预约 API，使用 POST 方法，RequestBody 为包含分区 ID 的分发请求对象。