# 1. API Gateway

API Gateway 是 Amazon 的一项服务，用于创建、发布、维护、监控和保护任何规模的 REST、HTTP 和 WebSocket API。API 开发者可以创建访问 Amazon 或其他网络服务的 API，以及存储在 Amazon Cloud 中的数据。作为 API Gateway API 开发者，你可以为自己的客户端应用创建 API。或者你可以把 API 开放给第三方应用开发者。

API Gateway 创建 RESTful API：
- 是基于 HTTP 的。
- 启用无状态客户端-服务器通信。
- 实现标准的 HTTP 方法，如 GET、POST、PUT、PATCH 和 DELETE。

API Gateway 创建 WebSocket API：
- 遵循 WebSocket 协议，该协议使客户端和服务器之间能够进行有状态的全双工通信。
- 根据消息内容路由来消息。

# 2. EC2

Amazon Elastic Compute Cloud（Amazon EC2）在 Amazon Web Services（Amazon）Cloud 中提供按需、可扩展的计算能力。使用 Amazon EC2 可以降低硬件成本，让你更快地开发和部署应用。你可以用 Amazon EC2 启动任意数量的虚拟服务器，配置安全和网络，管理存储。你可以增加容量（扩展）来处理计算密集的任务，比如每月或每年的流程，或网站流量激增。当使用量下降时，你可以再次减少容量（缩小）。

EC2 实例是亚马逊云中的虚拟服务器。当你启动 EC2 实例时，你指定的实例类型决定了实例可用的硬件。每种实例类型提供不同的计算、内存、网络和存储资源平衡。

# 3. ECS

Amazon Elastic Container Service（Amazon ECS）是一项全托管的容器编排服务，帮助您轻松部署、管理和扩展容器化应用。作为一项全托管服务，Amazon ECS 内置了 Amazon 配置和运营最佳实践。它集成了 Amazon 工具，如 Amazon 弹性容器注册表，以及第三方工具，如 Docker。这种集成使团队更容易专注于构建应用程序，而非环境。您可以在云端和本地运行和扩展容器工作负载，而无需复杂的控制平面管理。

Amazon ECS 有三层：
- Capacity —— 你的容器运行的基础设施
- Controller —— 部署和管理运行在容器上的应用程序
- Provisioning —— 你可以用来与调度器接口，部署和管理你的应用和容器的工具

# 4. VPC

通过 Amazon Virtual Private Cloud（Amazon VPC），你可以在你定义的逻辑隔离的虚拟网络中启动 Amazon 资源。这个虚拟网络与你在自己数据中心运营的传统网络非常相似，同时利用 Amazon 可扩展的基础设施。VPC 在区域内的每个可用区都有一个子网，每个子网都有 EC2 实例，并有一个互联网网关，允许 VPC 中的资源与互联网之间通信。

# 5. RDS

Amazon Relational Database Service（Amazon RDS）是一种网络服务，使在 Amazon Web Services Cloud 中更容易地搭建、操作和扩展关系数据库。它为行业标准关系数据库提供成本效益高、可调整规模的容量，并管理常见的数据库管理任务。

Amazon RDS 是一个托管数据库服务。它负责大多数管理任务。通过消除繁琐的手动流程，Amazon RDS 让您能够专注于应用和用户。

Amazon RDS 相比未完全托管的数据库部署，提供了以下主要优势：
- 可以使用已经熟悉的数据库引擎：IBM Db2、MariaDB、Microsoft SQL Server、MySQL、Oracle Database 和 PostgreSQL。
- Amazon RDS 负责备份、软件补丁、自动故障检测和恢复。
- 可以开启自动备份，或者手动创建自己的备份快照。可以用这些备份来恢复数据库。Amazon RDS 的恢复流程可靠且高效。
- 你可以通过一个主数据库实例和一个同步的备用数据库实例实现高可用性，当出现问题时可以切换到后者。你也可以用读副本来增加读的缩放。
- 除了数据库包的安全性外，你还可以通过使用亚马逊身份与访问管理（IAM）来定义用户和权限来控制访问。你也可以通过将数据库部署到虚拟专用云（VPC）中来保护它们。

# 6. DynamoDB

Amazon DynamoDB 是一个无服务器、全托管、分布式 NoSQL 数据库，在任何规模下性能均为个位数毫秒。

DynamoDB 满足你克服关系型数据库扩展和运营复杂性的需求。DynamoDB 专为需要在任何规模下稳定性能的运营工作负载而打造并优化。例如，无论用户数为 1000 万还是 1 亿，DynamoDB 都能稳定地提供个位数毫秒的性能。DynamoDB 自 2012 年推出以来，持续帮助您摆脱关系型数据库，同时降低成本并提升大规模性能。

来自各种规模、行业和地区的客户都使用 DynamoDB 构建现代化的无服务器应用，这些应用可以从小规模开始，并可全球扩展。DynamoDB 可扩展支持几乎任何规模的表，同时提供稳定的个位数毫秒性能和高可用性。

对于 Amazon Prime Day 等活动，DynamoDB 支持多个高流量的 Amazon 物业和系统，包括 Alexa、Amazon.com 网站以及所有 Amazon 物流中心。针对此类事件，DynamoDB API 已处理了来自 Amazon 资产和系统的数万亿次调用。DynamoDB 持续为数百个客户提供服务，其表峰值流量超过每秒超过 50 万次。它还服务于数百个桌面大小超过 200 TB 的客户，每小时处理超过 10 亿个请求。

# 7. MQ

Amazon MQ 是 Apache ActiveMQ Classic 和 RabbitMQ 的托管消息代理服务，负责消息代理的设置、运营和维护。 您可以使用行业标准的消息协议创建新的 Amazon MQ 代理， 或者将现有消息代理迁移到 Amazon MQ，而无需重写消息代码。

代理是一种运行在 Amazon MQ 上的消息代理环境。它是 Amazon MQ 的基本构建模块。消息代理支持软件应用和组件通过多种编程语言、操作系统和正式消息协议进行通信。你可以使用 Amazon MQ 代理进行大规模通信，云原生应用和组件。

# 8. CloudWatch

Amazon CloudWatch 实时监控您在中国的 Amazon Web Services 资源以及在中国运行的应用。你可以用 CloudWatch 收集和跟踪指标，这些指标是你想为资源和应用测量的变量。CloudWatch 警报会根据你定义的规则发送通知或自动更改你监控的资源。

Amazon CloudWatch 事件提供近实时的系统事件流，描述 Amazon Web Services（Amazon）资源的变化。通过简单且快速设置的规则，你可以匹配事件并将其路由到一个或多个目标函数或流。

您可以使用 Amazon CloudWatch Logs 监控、存储并访问来自 Amazon Elastic Compute Cloud（Amazon EC2）实例、Amazon CloudTrail 及其他来源的日志文件。

# 9. Lambda

Amazon Lambda 是一个计算服务，无需管理服务器即可运行代码。你的代码会自动扩展和缩减，采用按使用付费定价。

你可以用 Lambda 做：
- 文件处理：上传到 Amazon Simple Storage Service 时自动处理文件。
- 长期运行的工作流程：使用持久的 Lambda 函数构建有状态的多步骤工作流，可持续长达一年。非常适合订单处理、审批流程、人工流程以及需要记忆进度的复杂数据管道。
- 数据库操作与集成示例：响应数据库变更并自动化数据工作流程。
- 定时和周期性任务：使用 EventBridge 按常规时间表运行自动化操作。
- 流处理：处理实时数据流以进行分析和监控。
- 网页应用：构建可扩展的网页应用，自动根据需求调整。
- 移动后端：为移动和网页应用创建安全的 API 后端。
- 物联网后端：处理网页、移动、物联网及第三方 API 请求。

# 10. CodeCommit

Amazon CodeCommit 是由 Amazon Web Services 托管的版本控制服务，你可以用它私密地存储和管理云端资产（如文档、源代码和二进制文件）。CodeCommit 是一个安全、高度可扩展的托管源码控制服务，托管私有的 Git 仓库。CodeCommit 消除了你管理自己的源控系统或担心其基础设施扩展的需求。你可以用 CodeCommit 存储从代码到二进制文件的任何内容。它支持 Git 的标准功能，因此可以无缝连接你现有的基于 Git 的工具。

通过 CodeCommit，您可以：
- 享受由 Amazon 托管的全托管服务。CodeCommit 提供高服务可用性和耐用性，消除管理自身硬件和软件的行政负担。没有硬件可供配置和扩展，也没有服务器软件需要安装、配置和更新。
- 安全存储你的代码。CodeCommit 仓库在静止和传输时均加密。
- 协作开发代码。CodeCommit 仓库支持拉取请求，用户可以在合并到分支前互相审查和评论彼此的代码变更;自动向用户发送关于拉取请求和评论邮件的通知;以及更多。
- 轻松扩展你的版本控制项目。CodeCommit 仓库可以根据你的开发需求进行扩展。该服务可以处理文件或分支数量大、文件大小大且修订历史较长的仓库。
- 随时随地存放任何东西。CodeCommit 对你的仓库大小和存储文件类型没有限制。
- 整合其他亚马逊及第三方服务。CodeCommit 让你的仓库与 Amazon Cloud 中的其他生产资源保持在附近，这有助于提升开发生命周期的速度和频率。它与 IAM 集成，可以与其他 Amazon 服务并与其他仓库并行使用。
- 可以轻松迁移其他远程仓库的文件。你可以从任何基于 Git 的仓库迁移到 CodeCommit。
- 用你已经会的 Git 工具。CodeCommit 支持 Git 命令以及其自身的 Amazon CLI 命令和 API。

# 11. Cognito

Amazon Cognito 是一个面向网页和移动应用的身份认证平台。它是一个用户目录、一个认证服务器，以及一个 OAuth 2.0 访问令牌和亚马逊凭证的授权服务。通过 Amazon Cognito，您可以从内置的用户目录、企业目录以及 Google 和 Facebook 等消费者身份提供商中认证和授权用户。

用户池、身份池两个组成部分构成了 Amazon Cognito。它们可以独立或协同运行，根据您对用户的访问需求进行。

当你想认证并授权用户使用你的应用或 API 时，可以创建一个用户池。用户池是一个具有自助服务和管理员驱动用户创建、管理和认证功能的用户目录。您的用户池可以是独立的目录和 OIDC 身份提供者（IdP），也可以是第三方劳动力和客户身份提供者的中间服务提供商（SP）。你可以在应用中为组织的 SAML 2.0 和 OIDC IdP（带有用户池）的员工身份提供单点登录（SSO）。你还可以在应用中为组织在公共 OAuth 2.0 身份商店（如亚马逊、谷歌、苹果和脸书）中的客户身份提供单点登录（SSO）。用户池不需要与身份池集成。从用户池中，你可以直接向应用、网页服务器或 API 发送认证的 JSON 网络令牌（JWT）。

当你想授权认证或匿名用户访问你的 Amazon 资源时，可以建立一个 Amazon Cognito 身份池。身份池会为你的应用发放 Amazon 凭证，以向用户提供资源。你可以用可信的身份提供者来认证用户，比如用户池或 SAML 2.0 服务。它还可以选择性地为访客用户发放凭据。身份池同时使用基于角色和基于属性的访问控制来管理用户对访问 Amazon 资源的授权。身份池不需要与用户池集成。身份池可以直接接受来自劳动力和消费者身份提供商的认证声明。